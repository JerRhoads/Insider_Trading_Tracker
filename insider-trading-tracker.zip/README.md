# Insider Trading Tracker

Track insider trades using SEC Form 4 filings.

## Features

- Extracts recent insider Form 4 filings from the SEC EDGAR system.
- Parses XML filings to identify insider buy/sell activity.
- Aggregates data and detects trends.
- Sends notifications via Discord for high-impact trades.