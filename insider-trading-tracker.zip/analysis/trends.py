import pandas as pd

def summarize_trades(trade_list):
    df = pd.DataFrame(trade_list)
    summary = df.groupby(["issuer", "code"]).agg({"shares": "sum"}).reset_index()
    return summary