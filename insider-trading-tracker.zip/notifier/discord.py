from discord_webhook import DiscordWebhook

def send_discord_alert(message, webhook_url):
    webhook = DiscordWebhook(url=webhook_url, content=message)
    webhook.execute()