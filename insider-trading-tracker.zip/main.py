from edgar.fetch import get_recent_form4_ciks
from edgar.parse import parse_form4_xml
from analysis.trends import summarize_trades
from notifier.discord import send_discord_alert

if __name__ == "__main__":
    links = get_recent_form4_ciks(5)
    all_trades = []

    for link in links:
        try:
            trades = parse_form4_xml(link)
            all_trades.extend(trades)
        except Exception as e:
            print(f"Error parsing {link}: {e}")

    summary = summarize_trades(all_trades)
    print(summary)

    for _, row in summary.iterrows():
        if row['code'] in ['P', 'S']:
            msg = f"{row['issuer']}: Insider {row['code']} of {row['shares']} shares"
            send_discord_alert(msg, "https://discord.com/api/webhooks/your-webhook-url")