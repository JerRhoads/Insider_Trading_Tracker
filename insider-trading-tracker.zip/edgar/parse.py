import requests
from bs4 import BeautifulSoup

def parse_form4_xml(url):
    xml_url = url.replace("-index.htm", ".xml")
    res = requests.get(xml_url, headers={"User-Agent": "insider-tracker"})
    soup = BeautifulSoup(res.text, "lxml")

    insider_name = soup.find("reportingowner").find("rptownrname").text
    issuer = soup.find("issuer").find("issuername").text
    trans = soup.find_all("nonderivativeTransaction")

    transactions = []
    for t in trans:
        code = t.find("transactioncode").text
        shares = t.find("transactionshares").text
        transactions.append({
            "name": insider_name,
            "issuer": issuer,
            "code": code,
            "shares": float(shares)
        })

    return transactions