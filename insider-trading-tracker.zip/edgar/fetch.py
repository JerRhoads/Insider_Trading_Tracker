import requests
from bs4 import BeautifulSoup

def get_recent_form4_ciks(count=10):
    feed_url = "https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&CIK=&type=4&owner=include&count=100"
    headers = {"User-Agent": "insider-tracker"}
    res = requests.get(feed_url, headers=headers)
    soup = BeautifulSoup(res.text, "html.parser")
    entries = soup.find_all("entry")[:count]
    links = [entry.find("link")["href"] for entry in entries]
    return links